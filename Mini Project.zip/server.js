import express from 'express';
// import { getDepartments,getDepartment,insertDepartment, insertProduct,getProduct,getProducts,getStaff,getStaffInfo,insertStaffInfo,deleteProduct,checkauth,insertReq_Main,insertstaff_req} from './backend.js';
import * as backenFunctions from './backend.js'
import { dataToExcel } from './excel.js';
import path from 'path';
import { __filename, __dirname } from './dirname.js';
import bodyParser from 'body-parser';
import session from 'express-session';
import crypto from 'crypto';

const port = 5501;
// Function to generate a secure random string (secret key)
function generateSecretKey(length) {
    return crypto.randomBytes(length).toString('hex');
}
// Generate a 32-byte (256-bit) secret key
const secretKey = generateSecretKey(32);

const app = express();
app.use(express.json());
app.use(express.static("public"));
app.use(bodyParser.urlencoded({ extended: true }));
// Configure session middleware with the generated secret key
app.use(session({
  secret: secretKey,
  resave: false,
  saveUninitialized: true
}));

app.set("view engine","ejs");


app.use('/public', express.static(path.join(__dirname, 'public')));


app.listen(port, () => {
    console.log(`Example app listening on port ${port}`)
  })

function isAuthenticated(req, res, next) {
    if (req.session && req.session.Name) {
        return next();
    }
    res.redirect('/login'); // Redirect to login page if not authenticated
}

app.use((req, res, next) => {
  // Exclude login route from authentication check
  if (req.path === '/login'||req.path === '/Homepage'||req.path === '/change-password') {
      return next();
  }
  isAuthenticated(req, res, next);
});

function authorize(permissions) {
    return function(req, res, next) {
      // const userRole = req.body.role;
      const userRole = req.session.userRole;
      if (permissions.includes(userRole)) {
          next(); 
      } else {
          // res.status(401).send("You don't have access to this page");
          res.sendFile(__dirname + '/403.html')
          // res.status(403)
      }
    };
    }

//ERRORS

// app.use((req, res, next) => {
//   res.status(403).sendFile(__dirname + '/401.html');
// });

















//STATIC PAGES

app.get('/', (req,res)=>{
  res.sendFile(__dirname + '/public/Html/index.html');
})

app.get('/Homepage', (req,res)=>{
  const userRole = req.session.userRole
  if(userRole == "Admin"){
    res.redirect("/MainStore")
  }else if(userRole == "StoreAdmin"){
    res.redirect("/Department")
  }else{
    res.redirect("/Staff-Lab")
  }
})
 
app.get('/a', (req,res)=>{
  res.sendFile(__dirname + '/public/Html/a.html');
})
// authorize(["StoreAdmin","Admin"]) 
app.get( "/Products-Filter", (req, res)=>{
    res.sendFile(__dirname + '/public/Html/products.html')
})

app.get( "/Departments-Filter", authorize(["StoreAdmin","Admin"]) ,(req, res)=>{
  res.sendFile(__dirname + '/public/Html/departments.html')
})

app.get( "/Staff-Lab", authorize(["Staff","Lab Incharge"]) ,(req, res)=>{
  res.sendFile(__dirname + '/public/Html/staff_homepage.html')
})
app.get( "/Department", authorize(["StoreAdmin"]) ,(req, res)=>{
  res.sendFile(__dirname + "/public/Html/departmentHomepage.html");
})


app.get( "/MainStore", authorize(["Admin"]) ,(req, res)=>{
  res.sendFile(__dirname + '/public/Html/MainStoreHome.html');
})


//LOGIN



app.get("/login", (req, res) => {
  // res.sendFile(__dirname + '/public/Html/login.html');
  const errorMessage = req.query.error ? 'Invalid credentials' : null;
  res.render('login', { errorMessage });
});

app.post("/login", async (req,res,error) => {
  const { email_id, password } = req.body;

  const user = await backenFunctions.checkauth(email_id);
 
  // // console.log(email_id,password)
  if(user[0].pass_word ==  password){
    req.session.userRole = user[0].role;
    req.session.Name = user[0].Name;
    res.redirect("/Homepage")
    
  }
   else{
    res.redirect('/login?error=true');
   }
})

app.get("/change-password", (req, res) => {
  // res.sendFile(__dirname + '/public/Html/change_password.html');
  let errorMessage = null;
  if (req.query.error === 'invalid') {
    errorMessage = 'Invalid credentials';
  } else if (req.query.error === 'mismatch') {
    errorMessage = 'New password and confirm password do not match';
  }
  res.render('change_password', { errorMessage });
});

app.post("/change-password", async(req, res) => {
  const { email_id, current_password,new_password,confirm_password } = req.body;
  const user  = await backenFunctions.checkauth(email_id);
  if(user[0].pass_word ==  current_password){
     if(new_password == confirm_password){
        await backenFunctions.changePassword(email_id,new_password)
        res.send("Password Changed Successfully");
     }else{
      res.redirect('/change-password?error=mismatch');
     }
  }else{
    res.redirect('/change-password?error=invalid');
  }
});







//PRODUCTS



app.get("/Products", async (req,res,error) =>{
  try{
      const [columns,Product] = await backenFunctions.getProducts();
      res.render('index',{data:Product,columns:columns})
  }
  catch{
      
      console.error(error);
      res.status(500).send("Internal Server Error");
  }
})
app.get("/Product/:id", async (req,res,error) =>{
  try{
      const id = +req.params.id
      const [columns,Product] = await backenFunctions.getProduct(id);
      res.render('index',{data:Product,columns:columns})
  }
  catch{
      
      console.error(error);
      res.status(500).send("Internal Server Error");
  }
})
app.post("/addProduct", async (req,res,error) =>{
  const productName = req.body
  console.log(productName)

  const receivedData = req.body; // Received data
console.log('Data received from client:', receivedData);
})

app.post("/Products-Filter", async(req,res,error) =>{
  const {productName} = req.body
  
    await backenFunctions.insertProduct(productName)
    
    res.redirect("/Products-Filter")
  // res.status(201).send("Successfull")
  // console.log(productName)
})

app.delete("/Products-Delete", async(req,res,error)=>{
  const item = req.body
  await backenFunctions.deleteProduct(item.product_name)
  res.status(204).send("Successfull")

})

app.get("/ProductNames", async(req,res)=>{
  const product = await backenFunctions.ProductNames()
  res.json(product)
})
app.get("/ProductNamesId", async(req,res)=>{
  const product = await backenFunctions.ProductNamesId()
  res.json(product)
})

// app.post("/filteredProduct", async(req,res) =>{
//   console.log(req.body)
//   const {product_name} = req.body
//   console.log(product_name)
//   const [columns,Request]  =  await backenFunctions.filteredProduct(product_name);
//   res.render('index',{data:Request,columns:columns})
// })


// app.post("/filteredProduct", async (req, res) => {
//   try {
//       // Extract product_name from request body
//       const { product_name } = req.body;

//       // Fetch data based on the product_name
//       const [columns, Request] = await backenFunctions.filteredProduct(product_name);

//       const encodedColumns = JSON.stringify(columns);
//       const encodedRequest = JSON.stringify(Request);

//       // Redirect to another page with the data encoded in the URL
//       res.redirect(`/filtered-page?columns=${encodeURIComponent(encodedColumns)}&Request=${encodeURIComponent(encodedRequest)}`);
//   } catch (error) {
//       console.error('Error processing POST request:', error);
//       res.status(500).send('Internal server error');
//   }
// });

app.get("/filteredProduct", async(req, res) => {
  // Extract data from query parameters
  const product_name = req.query.product_name;
  const userRole = req.session.userRole
  
  // if(userRole == "Admin"){

  const [columns, Request] = await backenFunctions.filteredProduct(product_name);
  
    res.render('DS',{data:Request,columns:columns})
  // }
  // else{
  //   res.json("Later")
  // }
  // res.send("Successful")
});





//DEPARTMENTS



app.get("/Departments", async (req,res,error) =>{
    try{
        const [columns,department] = await backenFunctions.getDepartments();
        res.render('index',{data:department,columns:columns})
        // console.table(departments)
    }
    catch{
        
        console.error(error);
        res.status(500).send("Internal Server Error");
    }
  })
  app.get("/Department/:id", async (req,res,error) =>{
    try{
        const id = +req.params.id
        const [columns,department] = await backenFunctions.getDepartment(id);
        res.render('index',{data:department,columns:columns})
        // console.table(departments)
    }
    catch{
        
        console.error(error);
        res.status(500).send("Internal Server Error");
    }
  })
  app.post("/Department", async (req,res,error) =>{
    try {
      const {Department_id,Department_name} = req.body;
      const department = await backenFunctions.insertDepartment(Department_id, Department_name);
      res.status(201).send(department);

    }catch{
        
        console.error(error);
        res.status(500).send("Internal Server Error");
    }
  })

  app.get("/DepartmentNames", async(req,res)=>{
    const result = await backenFunctions.DepartmentNames()
    res.json(result)
  })



  // STAFF




  app.get("/StaffInfo", authorize(["StoreAdmin","Admin"]),async (req,res,error) =>{
    try{
        const [columns,Staff] = await backenFunctions.getStaffInfo();
        // res.send(Staff)
        res.render('index',{data:Staff,columns:columns})
    }
    catch{
        
        console.error(error);
        res.status(500).send("You don't have access to this page");
    }
  })
  app.get("/Staff/:id", async (req,res,error) =>{
    try{
        const id = +req.params.id
        const [columns,Staff] = await backenFunctions.getStaff(id);
        res.render('index',{data:Staff,columns:columns})
    }
    catch{
        
        console.error(error);
        res.status(500).send("Internal Server Error");
    }
  })
  app.post("/Staff", async (req,res,error) =>{
    try {
      const {Staff_id,Staff_name} = req.body;
      await backenFunctions.insertStaffInfo(Staff_id,Staff_name);
      res.status(201).send("SUCCESFULL");
    }catch{
        
        console.error(error);
        res.status(500).send("Internal Server Error");
    }
  })

  app.get("/StaffNames", async(req,res)=>{
    const product = await backenFunctions.StaffNames()
    res.json(product)
  })




//LAB

app.get("/LabNames", async(req,res)=>{
  const Names = await backenFunctions.LabNames()
  res.json(Names)
})





// FORM



  app.get('/form', async (req, res) => {
    const products = await backenFunctions.getProducts();
    // res.render('addProduct', { products: products[1] });
    res.render('add',{ products: products[1] })
    // res.send(products[1]);
});



  app.get('/req_main',authorize(["StoreAdmin"]), async(req,res)=>{
    res.sendFile(__dirname + "/public/Html/store_req_main.html")
  })
  app.post('/req_main',authorize(["StoreAdmin"]), async(req,res)=>{
    const Department_name = req.session.Name
    const {Product_name,quantity,requested_by,requested_at} = req.body
    await backenFunctions.insertReq_Main(Department_name,Product_name,quantity,requested_by,requested_at)
    res.status(201).send("SUCCESFULL");
  })





  app.get("/staff_req",authorize(["Staff","Lab Incharge"]),async(req,res)=>{
    res.sendFile(__dirname + "/public/Html/staff_req.html")
  })
  app.post("/staff_req" ,authorize(["Staff","Lab Incharge"]), async(req,res)=>{
    const {Product_name,quantity,Department_name,purpose,Name,requested_at} = req.body
    await backenFunctions.insertstaff_req(Product_name,quantity,Department_name,purpose,Name,requested_at)
    res.status(201).send("SUCCESFULL");
    // console.log(req.body);
  })

  // app.get("/check_req",async(req,res)=>{
  //   res.sendFile(__dirname + "/public/Html/check_req.html")
  // })
  app.get("/check_req",authorize(["Staff","Lab Incharge","StoreAdmin","Admin"]),async(req,res)=>{
      const name = req.session.Name
      const userRole = req.session.userRole
      if(userRole == "StoreAdmin"){
        const [columns,Request]  =  await backenFunctions.getSLRequestsDS(name);
        res.render('DS',{data:Request,columns:columns})
      }else if(userRole == "Staff" || name == "Lab Incharge"){
      const [columns,Request]  =  await backenFunctions.getSLRequests(name);
      res.render('SL',{data:Request,columns:columns})
    }
      })
  

  app.get("/check_req_product",authorize(["StoreAdmin","Admin"]),async(req,res)=>{
    const userRole = req.session.userRole
    if(userRole=="Admin"){
      const [columns,Request]  =  await backenFunctions.getDSRequestsProduct();
      res.render('DS',{data:Request,columns:columns})
    }else{
      const [columns,Request]  =  await backenFunctions.getSLRequestsProduct();
      res.render('DS',{data:Request,columns:columns})
    }
    
})



// EXCEL

app.post("/download_excel",async (req,res)=> {
  const data = JSON.parse(req.body.data);
  const columns = JSON.parse(req.body.columns);
    await dataToExcel(data, columns, res) ;
    
})


app.get("/return", (req,res)=>{
    res.redirect("/Homepage")
})


// STOCK

app.get("/main_stock",authorize(["StoreAdmin"]),async(req,res)=>{
  res.sendFile(__dirname + "/public/Html/stock.html")
})


app.post("/main_stock" , async(req,res)=>{
  const {product_name,product_description,quantity,created_at,name_of_supplier} = req.body
  await backenFunctions.insertMainStock(product_name,product_description,quantity,created_at,name_of_supplier)
  res.status(201).send("SUCCESFULL");
  // console.log(req.body);
})

app.get("/main_stock_display",async(req,res)=>{
  // const name = req.session.Name
  const [columns,Request]  =  await backenFunctions.getMainStock();
  
  res.render('DS',{data:Request,columns:columns})
 
})

