import React from 'react';
import  { useState, useEffect } from 'react';
import { Product } from "./components/product";
// import { Navbar } from './components/navbar';
// import { Hamburger } from './components/hamburger';
import { AddProduct } from './components/addProduct';


function App() {
    let [productNames, setproductNames] = useState([]);

    useEffect(() => {
        async function fetchProductNames() {
            try {
                const response = await fetch('/ProductNamesId');
                if (!response.ok) {
                    throw new Error('Failed to fetch product names');
                }
                const data = await response.json();
                
                setproductNames(data);
            } catch (error) {
                console.error('Error fetching product names:', error);
                // Handle error
            }
        }
        fetchProductNames();
    }, []);
  return (
    
        
    <div className="app container grid">
        {productNames.map(product =>{
            return <Product key={product.Product_id} product_name={product.Product_name} />
        })}
        <AddProduct/>
    </div>
  );
}

export default App;
