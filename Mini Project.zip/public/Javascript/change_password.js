import { passwordShow } from "./functions.js"

const Password1 = document.getElementById("Password1")
const eye1 = document.getElementById("eye-close1")
passwordShow(Password1, eye1)

const Password2 = document.getElementById("Password2")
const eye2 = document.getElementById("eye-close2")
passwordShow(Password2, eye2)

const Password3 = document.getElementById("Password3")
const eye3 = document.getElementById("eye-close3")
passwordShow(Password3, eye3)