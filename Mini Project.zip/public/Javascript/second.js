import { passwordShow } from "./functions.js";

const Password = document.getElementById("Password")
const eye = document.getElementById("eye-close")

passwordShow(Password, eye)