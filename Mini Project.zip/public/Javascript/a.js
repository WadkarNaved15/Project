import { Product } from "./filterProduct.js";

const ProductinputBox = document.getElementById('Product-input-box');

ProductinputBox.addEventListener('onclick',Product(ProductinputBox))



