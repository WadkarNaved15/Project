import mysql from 'mysql2'

import dotenv from 'dotenv'
dotenv.config()


const pool = mysql.createPool({
    host: process.env.MYSQL_HOST,
    user: process.env.MYSQL_USER,
    password: process.env.MYSQL_PASSWORD,
    database: process.env.MYSQL_DATABASE
}).promise()


//LOGIN

export async  function checkauth(email_id){
    const [result] = await pool.query(`SELECT * FROM login WHERE email_id = ?`,[email_id])
    return result
}

export async function getRole(email_id){
    const [result] = await pool.query(`SELECT  Role FROM Login WHERE email_id = ?`,[email_id]);
    return result
}

export async function changePassword(email_id,new_password){
    const [result] = await pool.query(`UPDATE Login
    SET pass_word = ?
    WHERE email_id = ? `,[new_password,email_id]);
    return result
}




// DEPARTMENTS



export async function DepartmentNames(){
    const [result] = await pool.query("SELECT Department_name FROM Department_Store ORDER BY Department_name ASC")
    return result;
}
export async function getDepartments(){
    const [result] = await pool.query("SELECT * FROM department_store ORDER BY Department_id ASC")
    if(result.length === 0) {return "No result in database.";}
    else{
    const columnNames = Object.keys(result[0]);
    return [columnNames,result]
}
}
export async function getDepartment(id){
    const [result] = await pool.query(`SELECT * 
    FROM Department_Store
    WHERE Department_id = ?`,[id])
    if(result.length === 0) {return "No result in database.";}
    else{
    const columnNames = Object.keys(result[0]);
    return [columnNames,result]
}
}
export async function insertDepartment(Department_id,Department_name){
    await pool.query(`INSERT IGNORE INTO Department_Store (Department_id,Department_name) VALUES (?,?)`,[Department_id,Department_name])
}

// PRODUCTS

export async function ProductNames(){
    const [result] = await pool.query("SELECT Product_name FROM Products ORDER BY Product_name ASC")
    return result;
}
export async function ProductNamesId(){
    const [result] = await pool.query("SELECT Product_id,Product_name FROM Products ORDER BY Product_id ASC")
    return result;
}

export async function getProducts(){
    const [result] = await pool.query("SELECT * FROM Products ORDER BY Product_id ASC")
    if(result.length === 0) {return "No result in database.";}
    else{
    const columnNames = Object.keys(result[0]);
    return [columnNames,result]
}
}
export async function getProduct(id){
    const [result] = await pool.query(`SELECT * 
    FROM Product
    WHERE Product_id = ?`,[id])
    if(result.length === 0) {return "No result in database.";}
    else{
    const columnNames = Object.keys(result[0]);
    return [columnNames,result]
    }
}
export async function insertProduct(Product_name){
    await pool.query(`INSERT ignore INTO Products (Product_name) values (?)`,[Product_name])
}

export async function deleteProduct(Product_name){
    await pool.query(`DELETE FROM Products WHERE Product_name = ? `,[Product_name])
}

export async function filteredProduct(product_name){
    const [result] = await pool.query(`SELECT * FROM stock WHERE Product_name = ? `,[product_name])
    if(result.length === 0) {return "No products in database."}
    else{
    const columnNames = Object.keys(result[0]);
    return [columnNames,result]
}
}

// STAFF


export async function StaffNames(){
    const [result] = await pool.query("SELECT Staff_name FROM Staff ORDER BY Staff_name ASC")
    return result;
}
export async function getStaffInfo(){
    const [result] = await pool.query("SELECT * FROM Staff ORDER BY Staff_id ASC")
    if(result.length === 0) {return "No result in database.";}
    else{
    const columnNames = Object.keys(result[0]);
    return [columnNames,result]
    }
}
export async function getStaff(id){
    const [result] = await pool.query(`SELECT * 
    FROM Staff
    WHERE Staff_id = ?`,[id])
    if(result.length === 0) {return "No result in database.";}
    else{
    const columnNames = Object.keys(result[0]);
    return [columnNames,result]
    }
}
export async function insertStaffInfo(Staff_id,Staff_name,email_id){
    await pool.query(`INSERT IGNORE INTO Staff (Staff_id,Staff_name,email_id) VALUES (?,?)`,[Staff_id,Staff_name,email_id])
}





// LAB

export async function LabNames(){
    const [result] = await pool.query("SELECT Lab_name FROM Lab ORDER BY Lab_name ASC")
    return result;
}
export async function getLabInfo(){
    const [result] = await pool.query("SELECT * FROM Lab ORDER BY Lab_id ASC")
    if(result.length === 0) {return "No result in database.";}
    else{
    const columnNames = Object.keys(result[0]);
    return [columnNames,result]
    }
}
export async function getLab(id){
    const [result] = await pool.query(`SELECT * 
    FROM Lab
    WHERE Lab_id = ?`,[id])
    if(result.length === 0) {return "No result in database.";}
    else{
    const columnNames = Object.keys(result[0]);
    return [columnNames,result]
    }
}
export async function insertLabInfo(Lab_id,Lab_name,email_id){
    await pool.query(`INSERT IGNORE INTO Staff (Lab_id,Lab_name,email_id) VALUES (?,?)`,[Lab_id,Lab_name,email_id])
}













// DS_REQ_MAIN

export async function insertReq_Main(Department_name,Product_name,quantity,requested_by,requested_at){
    await pool.query(`INSERT INTO ds_req_main (Department_name,Product_name,quantity,status,requested_by,requested_at) VALUES (?,?,?,"pending",?,?)`,[Department_name,Product_name,quantity,requested_by,requested_at])
}

export async function getDSRequestsProduct() {
    const [result] = await pool.query(`
        SELECT product_name, SUM(quantity) AS total_quantity
        FROM ds_req_main
        WHERE status = "pending"
        GROUP BY product_name
    `)
    if(result.length === 0) {return "No result in database.";}
    else{
    const columnNames = Object.keys(result[0]);
    return [columnNames,result]
    }
};



// SL_REQ_DS


export async function insertstaff_req(Product_name,quantity,Department_name,purpose,Name,requested_at){
    await pool.query(`INSERT INTO sl_req_ds (Product_name,quantity,Department_name,purpose,Name,status,requested_at) VALUES (?,?,?,?,?,"pending",?)`,[Product_name,quantity,Department_name,purpose,Name,requested_at])
}

export async function getSLRequests(name){
    const [result] = await pool.query(`SELECT * 
    FROM sl_req_ds
    WHERE name = ?
    ORDER BY requested_at DESC `,[name])
    if(result.length === 0) {return "No result in database.";}
    else{
    const columnNames = Object.keys(result[0]);
    return [columnNames,result]
    }
}

export async function getSLRequestsDS(name){
    const [result] = await pool.query(`SELECT * 
    FROM sl_req_ds
    WHERE department_name = ?
    ORDER BY requested_at DESC `,[name])
    if(result.length === 0) {return "No result in database.";}
    else{
    const columnNames = Object.keys(result[0]);
    return [columnNames,result]
    }
}

export async function getSLRequestsProduct() {
    const [result] = await pool.query(`
        SELECT product_name, SUM(quantity) AS total_quantity
        FROM sl_req_ds
        WHERE status = "pending"
        GROUP BY product_name
    `);
    
    // Extract column names from the result object
    if(result.length === 0) {return "No result in database.";}
    else{
    const columnNames = Object.keys(result[0]);
    return [columnNames,result]
    }
}




// STOCK 


export async function insertMainStock(Product_name,Product_description,quantity,created_at,name_of_supplier){
    await pool.query(`INSERT INTO Stock (Product_name,Product_description,quantity,created_at,name_of_supplier,status) VALUES (?,?,?,?,?,"available")`,[Product_name,Product_description,quantity,created_at,name_of_supplier])
}

export async function getMainStock() {
    const [result] = await pool.query(`SELECT *  FROM AvailableStock`);
    if(result.length === 0) {return "No stock available.";}
    else{
    const columnNames = Object.keys(result[0]);
    return [columnNames,result]
}
}
